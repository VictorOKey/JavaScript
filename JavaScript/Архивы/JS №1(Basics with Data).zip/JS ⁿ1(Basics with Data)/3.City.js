function InfoCity(town_name, population, area) {
		console.log(`Town ${town_name} has population of ${population} and area ${area} square km`);
}
InfoCity("Krasnoarmeysk", 26300, 156);