function intoString(str1, str2, str3) {
	console.log(`${str1}${str2}${str3}`);
}
intoString("a", "b", "c");
intoString("$", "2", "o");
intoString("1", "5", "p");