function Lowest(n1,n2){
    return n1<n2? n1:n2;
}
console.log(Lowest(Lowest(2,5),3));
console.log(Lowest(Lowest(600,342),123));
console.log(Lowest(Lowest(25,21),4));