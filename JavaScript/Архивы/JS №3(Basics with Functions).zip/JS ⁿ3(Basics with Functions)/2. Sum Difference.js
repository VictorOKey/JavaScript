
function solve(n1,n2){
    return n1[0]+n1[1]-n2;
}

console.log(solve([23,6],10));
console.log(solve([1,17],30));
console.log(solve([42,58],100));