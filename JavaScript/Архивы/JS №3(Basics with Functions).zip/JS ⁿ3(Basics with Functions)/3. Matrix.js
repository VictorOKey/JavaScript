function MatrixN(n){
    let str="";
    for (let i = 0; i < n; i++) {
        for (let j = 0; j < n; j++) {
           s+=n+" ";
        }
        console.log(s);
        str="";
    }
}

MatrixN(3);
MatrixN(7);
MatrixN(2);